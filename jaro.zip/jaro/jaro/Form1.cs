﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jaro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(jaro(textBox1.Text, textBox2.Text).ToString());
        }
        public double jaro(string x,string y)
        {
            int str1_len = x.Length;
            int str2_len = y.Length;
            if (str1_len == 0) return str2_len == 0 ? 1.0 : 0.0;
            int match_distance = (int)Math.Max(str1_len, str2_len) / 2 - 1;
            int[] str1_matches = new int[x.Length];
            int[] str2_matches = new int[y.Length];
            double matches = 0;
            double transpositions = 0;
            for(int i=0;i<str1_len;i++)
            {
                int start = Math.Max(0, i - match_distance);
                int end = Math.Min(i + match_distance + 1, str2_len);
                for(int t=start;t<end;t++)
                {
                    if(x[i]==y[t] && str2_matches[t]==0)
                    {
                        str1_matches[i] = 1;
                        str2_matches[t] = 1;
                        matches++;
                        break;
                    }
                }
            }
            if (matches == 0) return 0.0;
            int point = 0;
            for(int i=0;i<str1_len;i++)
            {
                if(str1_matches[i]==1)
                {
                    while (str2_matches[point] == 0) point++;
                    if (x[i] != y[point++]) transpositions++;
                }
            }
            transpositions = transpositions / 2;
            return ((matches / str1_len) + (matches / str2_len) + ((matches - transpositions
                ) / matches)) / 3;
        }
    }
}
